import "./styles/main.scss"
// @ts-ignore
if (module.hot) {
	// @ts-ignore
	module.hot.accept()
}
console.log("log from index.ts.")
